# Terrain Traversal Simulation — skid-steer, hilly heightmap terrain

ROS 2 Humble + Gazebo Classic 11. 4-wheel skid-steer robot on a procedurally
generated hilly heightmap (40m x 40m, ~4m max relief, flat spawn zone at origin).

## Package layout

```
skidsteer_terrain_sim/
├── urdf/skidsteer_robot.urdf.xacro   # chassis, 4 wheels, IMU, ros2_control
├── worlds/hilly_terrain.world        # includes terrain_heightmap model
├── models/terrain_heightmap/         # SDF heightmap model + heightmap.png
├── config/controllers.yaml           # diff_drive_controller, 2 wheels/side
├── config/slam_toolbox_params.yaml   # online async SLAM mapping
├── config/nav2_params.yaml           # controller/planner/behavior/bt_navigator + costmaps
├── launch/terrain_sim.launch.py      # gazebo + spawn + controllers
├── launch/traversal_tools.launch.py  # rviz + tilt monitor + optional auto-drive
├── launch/slam_navigation.launch.py  # slam_toolbox + full Nav2 stack + rviz
├── scripts/tilt_math.py              # ROS-free pitch/roll math (pytest-covered)
├── scripts/test_tilt_math.py         # pytest — already passing
├── scripts/traversal_monitor.py      # IMU -> tip-over warnings
├── scripts/auto_drive.py             # optional: wanders the terrain on its own
└── tools/generate_heightmap.py       # regenerate heightmap.png if you want a new map
```

## Build

```bash
cd ~/ros2_ws   # or wherever this src/ gets merged into
colcon build --packages-select skidsteer_terrain_sim
source install/setup.bash
```

## Run

```bash
ros2 launch skidsteer_terrain_sim terrain_sim.launch.py
```

Wait for Gazebo to load, then in a second terminal:

```bash
ros2 launch skidsteer_terrain_sim traversal_tools.launch.py
```

This opens RViz and starts `traversal_monitor` (logs `TIP-OVER RISK` warnings if
pitch/roll exceed 30°, tunable via `tip_over_threshold_deg` param).

### Drive it

Manual (recommended for testing slope handling):
```bash
ros2 run teleop_twist_keyboard teleop_twist_keyboard \
  --ros-args -r cmd_vel:=/skid_steer_controller/cmd_vel_unstamped
```

Or let it wander on its own:
```bash
ros2 launch skidsteer_terrain_sim traversal_tools.launch.py auto_drive:=true
```

## SLAM + Navigation

The robot has a 360° 2D lidar on `/scan`. Eight static rock obstacles sit
inside the guaranteed-flat spawn disk (radius < 5.6m) so the lidar/SLAM/Nav2
stack has real vertical features to map and avoid — plain hills alone don't
give a 2D lidar anything to see, since it maps obstacle silhouettes, not
ground elevation.

```bash
# Terminal 1 (unchanged)
ros2 launch skidsteer_terrain_sim terrain_sim.launch.py

# Terminal 2: SLAM (mapping) + full Nav2 stack + RViz
ros2 launch skidsteer_terrain_sim slam_navigation.launch.py
```

In RViz: use the **2D Goal Pose** tool (or the Navigation2 panel) to send a
goal. The robot plans around the rocks and drives itself there via
`skid_steer_controller`. Drive it manually first with teleop to build up
some map coverage before sending distant goals — Nav2 can only plan through
space slam_toolbox has already seen.

Save the map once you're happy with the coverage:
```bash
ros2 run nav2_map_server map_saver_cli -f ~/my_terrain_map
```

Notes:
- `bt_navigator`'s behavior tree XML path is resolved from `nav2_bt_navigator`'s
  own share directory at launch time rather than hardcoded, to avoid the
  stale-path issue from `diffbot_nav_ws`.
- No `amcl`/`map_server` here — this is live SLAM, not localization on a
  saved map. The global costmap's static layer subscribes directly to
  slam_toolbox's `/map` topic.
- `cmd_vel` from `controller_server`/`behavior_server` is remapped to
  `/skid_steer_controller/cmd_vel_unstamped`, same topic teleop uses.
- Rocks are only guaranteed to sit correctly on flat ground (radius < 5.6m
  from origin) — see `tools/generate_heightmap.py` if you want obstacles
  further out on the hills, you'll need to sample real terrain height there.

## Notes

- Skid-steer is implemented via `diff_drive_controller` with 2 wheel joints
  per side (`left_wheel_names`/`right_wheel_names` lists) rather than a
  dedicated skid-steer plugin — this is the standard ROS 2 approach since
  `gazebo_ros2_control` + `ros2_controllers` don't ship a 4-wheel skid-steer
  controller. `wheel_separation_multiplier: 1.6` roughly compensates for
  ground-contact scrub during turns; tune it against your actual `mu1/mu2`
  friction values in the xacro if odometry drifts too much.
- Heightmap is baked into `models/terrain_heightmap/materials/textures/heightmap.png`.
  Re-run `tools/generate_heightmap.py` to reshape the terrain (edit
  `hill_centers`, `MAX_HEIGHT`, or `FLAT_RADIUS_PX` at the top of the script).
- Robot spawns at `(0, 0, 0.35)` — matches the flattened disk in the heightmap
  center. If you enlarge the flat zone or move hills closer to origin, adjust
  the spawn `-z` in `terrain_sim.launch.py` accordingly.
- IMU publishes on `/imu` via `libgazebo_ros_imu_sensor.so`.
