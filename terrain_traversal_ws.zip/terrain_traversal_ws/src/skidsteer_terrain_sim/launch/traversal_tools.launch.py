import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch.conditions import IfCondition
from launch_ros.actions import Node


def generate_launch_description():
    pkg_share = get_package_share_directory('skidsteer_terrain_sim')
    rviz_config = os.path.join(pkg_share, 'rviz', 'terrain_sim.rviz')

    auto_drive_arg = DeclareLaunchArgument(
        'auto_drive', default_value='false',
        description='If true, launches the auto_drive demo node (else drive manually with teleop_twist_keyboard)',
    )

    monitor_node = Node(
        package='skidsteer_terrain_sim',
        executable='traversal_monitor.py',
        output='screen',
        parameters=[{'use_sim_time': True, 'tip_over_threshold_deg': 30.0}],
    )

    auto_drive_node = Node(
        package='skidsteer_terrain_sim',
        executable='auto_drive.py',
        output='screen',
        parameters=[{'use_sim_time': True}],
        condition=IfCondition(LaunchConfiguration('auto_drive')),
    )

    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        arguments=['-d', rviz_config],
        parameters=[{'use_sim_time': True}],
        output='screen',
    )

    return LaunchDescription([
        auto_drive_arg,
        monitor_node,
        auto_drive_node,
        rviz_node,
    ])
