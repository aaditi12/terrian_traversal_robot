import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource


def generate_launch_description():
    pkg_share = get_package_share_directory('skidsteer_terrain_sim')

    terrain_sim = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_share, 'launch', 'terrain_sim.launch.py')
        )
    )

    # terrain_sim.launch.py brings up the EKF at t=7s internally. Starting
    # SLAM any earlier means slam_toolbox initializes against a TF tree
    # that doesn't have odom->base_link yet (the "map not present" / stuck
    # mapping symptom). 12s gives a real margin past that, including slower
    # VM startup for gzserver + controller_manager.
    autonomous_nav = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_share, 'launch', 'autonomous_nav.launch.py')
        )
    )
    delayed_autonomous_nav = TimerAction(period=12.0, actions=[autonomous_nav])

    return LaunchDescription([
        terrain_sim,
        delayed_autonomous_nav,
    ])
