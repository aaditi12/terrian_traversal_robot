import os
import re

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import ExecuteProcess, SetEnvironmentVariable, TimerAction
from launch_ros.actions import Node
import xacro


def generate_launch_description():
    pkg_share = get_package_share_directory('skidsteer_terrain_sim')

    world_path = os.path.join(pkg_share, 'worlds', 'hilly_terrain.world')
    xacro_path = os.path.join(pkg_share, 'urdf', 'skidsteer_robot.urdf.xacro')
    controllers_yaml = os.path.join(pkg_share, 'config', 'controllers.yaml')
    ekf_yaml = os.path.join(pkg_share, 'config', 'ekf_params.yaml')

    # Make the terrain_heightmap model (and its heightmap.png) discoverable by Gazebo
    models_path = os.path.join(pkg_share, 'models')

    robot_description_xml = xacro.process_file(
        xacro_path, mappings={'controllers_config': controllers_yaml}
    ).toxml()

    # gazebo_ros2_control hands robot_description to rclcpp as a
    # "--param robot_description:=<xml>" argument override. XML comments
    # (including xacro's own auto-inserted banner) and stray newlines break
    # that argument's internal parsing and crash the whole gazebo process.
    # Strip comments and collapse whitespace so it survives as one clean token.
    robot_description_xml = re.sub(r'<!--.*?-->', '', robot_description_xml, flags=re.DOTALL)
    robot_description_xml = re.sub(r'>\s+<', '><', robot_description_xml).strip()

    set_model_path = SetEnvironmentVariable(
        name='GAZEBO_MODEL_PATH',
        value=models_path + ':' + os.environ.get('GAZEBO_MODEL_PATH', ''),
    )

    gazebo = ExecuteProcess(
        cmd=['gazebo', '--verbose', world_path,
             '-s', 'libgazebo_ros_init.so',
             '-s', 'libgazebo_ros_factory.so'],
        output='screen',
    )

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_description_xml,
                     'use_sim_time': True}],
    )

    spawn_robot = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-topic', 'robot_description',
            '-entity', 'skidsteer_robot',
            # z=0.15 matches base_z (wheel_radius + ground_clearance) in the
            # xacro, so wheels touch down at spawn instead of free-falling
            # ~0.35m and slamming the IMU/EKF with a startup impact spike.
            '-x', '0.0', '-y', '0.0', '-z', '0.15',
        ],
        output='screen',
    )

    joint_state_broadcaster_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['joint_state_broadcaster'],
        output='screen',
    )

    skid_steer_controller_spawner = Node(
        package='controller_manager',
        executable='spawner',
        arguments=['skid_steer_controller'],
        output='screen',
    )

    # Stagger controller startup slightly after spawn so the controller_manager
    # (created by gazebo_ros2_control when the robot is spawned) is ready.
    delayed_joint_state_broadcaster = TimerAction(
        period=4.0, actions=[joint_state_broadcaster_spawner]
    )
    delayed_skid_steer_controller = TimerAction(
        period=6.0, actions=[skid_steer_controller_spawner]
    )

    # EKF fuses wheel odom + IMU into a slip-corrected odom->base_link TF.
    # Started after the controller spawns so /skid_steer_controller/odom
    # already exists.
    ekf_node = Node(
        package='robot_localization',
        executable='ekf_node',
        name='ekf_filter_node',
        output='screen',
        parameters=[ekf_yaml],
    )
    delayed_ekf = TimerAction(period=7.0, actions=[ekf_node])

    return LaunchDescription([
        set_model_path,
        gazebo,
        robot_state_publisher,
        spawn_robot,
        delayed_joint_state_broadcaster,
        delayed_skid_steer_controller,
        delayed_ekf,
    ])
