#!/usr/bin/env python3
"""
auto_drive node.

Simple demo driver: sends a constant forward + gentle sweeping turn command
on /skid_steer_controller/cmd_vel_unstamped so the robot wanders over the
hilly terrain without manual teleop. Stop it any time and drive manually with
teleop_twist_keyboard on the same topic.
"""
import math

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist


class AutoDrive(Node):
    def __init__(self):
        super().__init__('auto_drive')
        self.declare_parameter('linear_speed', 0.4)
        self.declare_parameter('turn_amplitude', 0.3)
        self.declare_parameter('turn_period_s', 8.0)

        self.linear_speed = self.get_parameter('linear_speed').value
        self.turn_amplitude = self.get_parameter('turn_amplitude').value
        self.turn_period = self.get_parameter('turn_period_s').value

        self.pub = self.create_publisher(
            Twist, '/skid_steer_controller/cmd_vel_unstamped', 10
        )
        self.t0 = self.get_clock().now()
        self.timer = self.create_timer(0.1, self.tick)
        self.get_logger().info('auto_drive started - wandering over the terrain')

    def tick(self):
        elapsed = (self.get_clock().now() - self.t0).nanoseconds * 1e-9
        msg = Twist()
        msg.linear.x = self.linear_speed
        msg.angular.z = self.turn_amplitude * math.sin(
            2 * math.pi * elapsed / self.turn_period
        )
        self.pub.publish(msg)


def main():
    rclpy.init()
    node = AutoDrive()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
