#!/usr/bin/env python3
"""
traversal_monitor node.

Subscribes to /imu, converts orientation to pitch/roll (via ROS-free tilt_math),
and logs a warning if the robot's tilt exceeds a safety threshold while
traversing the hilly terrain.
"""
import math

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu

from tilt_math import quaternion_to_pitch_roll, tip_over_risk

TIP_OVER_THRESHOLD_DEG = 30.0


class TraversalMonitor(Node):
    def __init__(self):
        super().__init__('traversal_monitor')
        self.declare_parameter('tip_over_threshold_deg', TIP_OVER_THRESHOLD_DEG)
        self.threshold_rad = math.radians(
            self.get_parameter('tip_over_threshold_deg').value
        )
        self.sub = self.create_subscription(Imu, '/imu', self.imu_cb, 20)
        self._last_log_ok = True
        self.get_logger().info(
            f'traversal_monitor started, tip-over threshold = '
            f'{math.degrees(self.threshold_rad):.1f} deg'
        )

    def imu_cb(self, msg: Imu):
        q = msg.orientation
        pitch, roll = quaternion_to_pitch_roll(q.x, q.y, q.z, q.w)

        if tip_over_risk(pitch, roll, self.threshold_rad):
            self.get_logger().warn(
                f'TIP-OVER RISK: pitch={math.degrees(pitch):.1f} deg, '
                f'roll={math.degrees(roll):.1f} deg'
            )
            self._last_log_ok = False
        elif not self._last_log_ok:
            self.get_logger().info('Tilt back within safe range.')
            self._last_log_ok = True
        else:
            self.get_logger().debug(
                f'pitch={math.degrees(pitch):.1f} deg roll={math.degrees(roll):.1f} deg'
            )


def main():
    rclpy.init()
    node = TraversalMonitor()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
