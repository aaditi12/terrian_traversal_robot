import math
from tilt_math import quaternion_to_pitch_roll, tip_over_risk


def test_identity_quaternion_is_level():
    pitch, roll = quaternion_to_pitch_roll(0, 0, 0, 1)
    assert math.isclose(pitch, 0.0, abs_tol=1e-9)
    assert math.isclose(roll, 0.0, abs_tol=1e-9)


def test_90deg_roll():
    # 90 deg rotation about x-axis
    half = math.pi / 4
    x, y, z, w = math.sin(half), 0, 0, math.cos(half)
    pitch, roll = quaternion_to_pitch_roll(x, y, z, w)
    assert math.isclose(roll, math.pi / 2, abs_tol=1e-6)
    assert math.isclose(pitch, 0.0, abs_tol=1e-6)


def test_tip_over_risk_flags_large_tilt():
    threshold = math.radians(30)
    assert tip_over_risk(math.radians(35), 0.0, threshold) is True
    assert tip_over_risk(0.0, math.radians(35), threshold) is True
    assert tip_over_risk(math.radians(10), math.radians(10), threshold) is False
