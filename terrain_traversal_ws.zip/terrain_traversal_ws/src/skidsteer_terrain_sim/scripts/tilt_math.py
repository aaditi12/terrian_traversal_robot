"""
Pure math, zero ROS imports. Covered by plain pytest (see test_tilt_math.py).
"""
import math


def quaternion_to_pitch_roll(x: float, y: float, z: float, w: float) -> tuple[float, float]:
    """Convert a quaternion to (pitch, roll) in radians, ZYX convention."""
    # roll (x-axis rotation)
    sinr_cosp = 2.0 * (w * x + y * z)
    cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(sinr_cosp, cosr_cosp)

    # pitch (y-axis rotation)
    sinp = 2.0 * (w * y - z * x)
    sinp = max(-1.0, min(1.0, sinp))  # clamp for numerical safety
    pitch = math.asin(sinp)

    return pitch, roll


def tip_over_risk(pitch: float, roll: float, threshold_rad: float) -> bool:
    """True if either pitch or roll magnitude exceeds the safety threshold."""
    return abs(pitch) > threshold_rad or abs(roll) > threshold_rad
