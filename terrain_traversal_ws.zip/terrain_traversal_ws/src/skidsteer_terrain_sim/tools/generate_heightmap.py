#!/usr/bin/env python3
"""
Generates heightmap.png for the hilly terrain world.
Run once (already done for this deliverable) if you want to regenerate:
    python3 generate_heightmap.py

Output: ../models/terrain_heightmap/materials/textures/heightmap.png
Size: 129x129 (2^n+1, Gazebo-friendly)
World size: 40m x 40m, max height: 4m (set to match worlds/hilly_terrain.world)

Slope budget: this robot's chassis (0.34m wheelbase, ~0.225m CG height,
see skidsteer_robot.urdf.xacro) tips over above ~30 deg and starts losing
front-wheel traction well before that. MAX_SLOPE_DEG below is enforced by
construction (amplitude/sigma chosen from it, not guessed) and then
double-checked numerically after generation.
"""
import numpy as np
from PIL import Image
import os

SIZE = 129            # pixels (2^n + 1)
WORLD_SIZE = 40.0     # meters
MAX_HEIGHT = 4.0       # meters
FLAT_RADIUS_PX = 18    # keep area around spawn point flat/gentle
MAX_SLOPE_DEG = 22.0   # hard budget, well under the ~30 deg tip-over limit

rng = np.random.default_rng(42)

x = np.linspace(-WORLD_SIZE / 2, WORLD_SIZE / 2, SIZE)
y = np.linspace(-WORLD_SIZE / 2, WORLD_SIZE / 2, SIZE)
X, Y = np.meshgrid(x, y)
res = WORLD_SIZE / (SIZE - 1)  # meters per pixel

height = np.zeros_like(X)

# A handful of randomly placed gaussian hills, kept away from center.
# Steepest slope of a single gaussian bump of amplitude A and width sigma
# is A * sqrt(2/e) / sigma =~ 0.858 * A / sigma. Pick amp/sigma pairs so
# that, even with a couple of hills overlapping, we stay under budget.
hill_centers = [
    (-12, -10), (10, 12), (14, -8), (-9, 13),
    (0, -16), (16, 2), (-16, -2), (5, 16),
]
max_single_slope = np.tan(np.radians(MAX_SLOPE_DEG)) / 1.6  # margin for overlap between neighboring hills
for (cx, cy) in hill_centers:
    amp = rng.uniform(0.35, 0.55) * MAX_HEIGHT
    # solve sigma from the slope budget: sigma = 0.858 * amp / max_single_slope
    sigma = 0.858 * amp / max_single_slope
    sigma = max(sigma, 5.0)  # keep hills reasonably broad/rolling, not narrow bumps
    height += amp * np.exp(-(((X - cx) ** 2 + (Y - cy) ** 2) / (2 * sigma ** 2)))

# Gentle rolling ridge across the whole map for a mild slope-climb challenge
height += 0.35 * MAX_HEIGHT * (0.5 + 0.5 * np.sin(X / 10.0)) * 0.3

# Flatten a disk around the origin, smoothly ramping back to full terrain
# height over a transition band so there's no cliff at the boundary.
cx_px, cy_px = SIZE // 2, SIZE // 2
yy, xx = np.mgrid[0:SIZE, 0:SIZE]
dist_px = np.sqrt((xx - cx_px) ** 2 + (yy - cy_px) ** 2)
TRANSITION_PX = FLAT_RADIUS_PX * 1.6  # wider ramp so flattening doesn't re-introduce a steep edge
weight = np.clip((dist_px - FLAT_RADIUS_PX) / TRANSITION_PX, 0.0, 1.0)
weight = weight * weight * (3 - 2 * weight)  # smoothstep, avoids a kinked slope
height = height * weight

# Overlapping hills add slope where they face each other, so the
# amplitude/sigma picked per-hill isn't a reliable ceiling on the summed
# field. Rather than guess a bigger margin, directly scale the *whole*
# field down until the measured slope actually fits the budget -- this
# also correctly accounts for the ridge term and the flattening step.
height = np.clip(height, 0, None)
for _ in range(25):
    gy, gx = np.gradient(height, res)
    cur_max_deg = np.degrees(np.arctan(np.sqrt(gx**2 + gy**2))).max()
    if cur_max_deg <= MAX_SLOPE_DEG:
        break
    # scale in tan-space (slope proportional to tan of angle, not the angle itself)
    scale = np.tan(np.radians(MAX_SLOPE_DEG)) / np.tan(np.radians(cur_max_deg))
    height *= scale * 0.98  # small extra margin so rounding to uint8 doesn't push it back over

# IMPORTANT: normalize against the fixed MAX_HEIGHT (which matches the
# <size>...</size> z value in hilly_terrain.world), not against this
# terrain's actual peak. If we stretched to fill 0-255 using the actual
# (now-smaller) peak, Gazebo would scale pixel 255 back up to MAX_HEIGHT
# and undo the slope-budget scaling above.
h_max_final = height.max()
normalized = np.clip(height / MAX_HEIGHT * 255, 0, 255).astype(np.uint8)
print(f"Peak terrain height after slope-budget scaling: {h_max_final:.2f} m (world file cap: {MAX_HEIGHT} m)")

# --- verify the slope budget numerically on the actual output pixels ---
height_m = normalized.astype(float) * (MAX_HEIGHT / 255.0)
gy, gx = np.gradient(height_m, res)
slope_deg = np.degrees(np.arctan(np.sqrt(gx**2 + gy**2)))
print(f"Generated slope stats -> max: {slope_deg.max():.1f} deg, "
      f"mean: {slope_deg.mean():.1f} deg, 99th pct: {np.percentile(slope_deg, 99):.1f} deg "
      f"(budget: {MAX_SLOPE_DEG:.1f} deg)")
if slope_deg.max() > MAX_SLOPE_DEG + 3:
    print("WARNING: generated terrain exceeds slope budget by more than the expected margin.")

out_dir = os.path.join(os.path.dirname(__file__), "..", "models", "terrain_heightmap", "materials", "textures")
os.makedirs(out_dir, exist_ok=True)
out_path = os.path.join(out_dir, "heightmap.png")

Image.fromarray(normalized, mode="L").save(out_path)
print(f"Wrote {out_path} ({SIZE}x{SIZE}), world size {WORLD_SIZE}m, max height {MAX_HEIGHT}m")

# Save the slope data alongside for the visualization step (not used by Gazebo).
np.save(os.path.join(os.path.dirname(__file__), "_slope_deg_cache.npy"), slope_deg)
